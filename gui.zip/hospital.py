

class Hospihal:
    def __init__(self,yadmname,addr,cl,xpos,ypos,telno):
        self.yadm =yadmname
        self.addr = addr
        self.cl=cl
        self.xpos=xpos
        self.ypos=ypos
        self.telno=telno
