from distutils.core import setup

setup(name='Hospital',
      version='1.0',
      py_modules=['GUItest','hosdata','hospital','mail','near','script http','search']
      )
